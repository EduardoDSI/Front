



//dice que el valor no va a cambiar en el tiempo

export const AccionMantConst = {
    crear: 1,
    editar: 2,
    eliminar: 3
}



const nombre = "Soto Galvan";













export const dominio = "https://localhost:7252/";


export const urlConstants = {

    ubigeo: dominio + "api/ubigeo/",
    rol: dominio + "api/rol/",
    usuario: dominio + "api/usuario/",
    persona: dominio + "api/persona/",
    auth: dominio + "api/auth/",
    direccion: dominio + "api/direccion/",
    detalleDeuda: dominio + "api/detalleDeuda/",
    deuda: dominio + "api/deuda/",
    pedido: dominio + "api/pedido/"

}
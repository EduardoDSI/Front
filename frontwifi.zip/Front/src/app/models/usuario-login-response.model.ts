export class UsuarioLoginResponse {
    id: number = 0;
    usuario1: string = "";
    contrasenia: string = "";
    idPersona: number = 0;
    idRol: number = 0;

}
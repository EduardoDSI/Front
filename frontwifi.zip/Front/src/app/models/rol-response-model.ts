export class RolResponse {
    id: number = 0;
    funcion: string = "";
    idPersona: number = 0;
}
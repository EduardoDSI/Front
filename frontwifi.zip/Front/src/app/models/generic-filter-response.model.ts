export class GenericFilterResponse<T> {
    totalRegistros: number = 0;
    lista: T[] = [];
}
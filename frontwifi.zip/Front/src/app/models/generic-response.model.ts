export class GenericResponse {
    success: boolean = false;
    codigo: string = "";
    descripcion: string = "";
    mensaje: string = "";
    mensajeSistema: string = "";
}
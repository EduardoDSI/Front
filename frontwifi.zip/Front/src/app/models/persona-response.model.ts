export class PersonaResponse {
    id: number = 0;
    nombres: string = "";
    apellidoPaterno: string = "";
    apellidoMaterno: string = "";
    fechaNacimiento: string = "";
    correoElectronico: string = "";
    tipoPersona: string = "";
    numeroCelular: string = "";
    nroIdentificacion: string = "";
    idTipoDocumento: number = 0;


}
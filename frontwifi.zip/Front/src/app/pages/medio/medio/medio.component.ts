import { Component } from '@angular/core';

@Component({
  selector: 'app-medio',
  templateUrl: './medio.component.html',
  styleUrls: ['./medio.component.scss']
})
export class MedioComponent {

}

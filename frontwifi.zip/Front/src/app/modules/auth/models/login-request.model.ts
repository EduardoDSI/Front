export class LoginRequest {
    usuario: string = "";
    contraseña: string = "";
}
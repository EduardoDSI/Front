import { Component } from '@angular/core';

@Component({
  selector: 'app-template-footer',
  templateUrl: './template-footer.component.html',
  styleUrls: ['./template-footer.component.scss']
})
export class TemplateFooterComponent {

}

export class UbigeoRequest {
    id: number = 0;
    departamento: string = "";
    provincia: string = "";
    distrito: string = "";
}
export class PedidoRequest {
    id: number =0; 
    fecha: string="";
    cita: string="";
    numPedido: string ="";  
    tipoComprobante: string ="";  
    descuento: string =""; 
    idPersona: number =0;

}
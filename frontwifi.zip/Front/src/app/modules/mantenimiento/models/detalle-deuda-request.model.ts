export class DetalleDeudaRequest {  
    id: number = 0;
    tipo: string = "";
    descripcion: string = "";
    cargo: string = "";
    descuento: string = "";
    monto: string = "";
    idDeuda: number = 0;
}
    
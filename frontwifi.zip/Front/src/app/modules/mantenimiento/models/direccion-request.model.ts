export class DireccionRequest {
    id: number = 0;
    calle: string = "";
    referencia: string = "";
    idPersona: number = 0;
}
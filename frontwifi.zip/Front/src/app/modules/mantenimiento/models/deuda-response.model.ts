export class DeudaResponse {
    id: number = 0;
    costoTotal: string = "";
    igv: string = "";
    fechaCargo: string = "";
    fechaPagada: string = "";
    abono: string = "";
    estado: string = "";
    idCliente: number = 0;
}
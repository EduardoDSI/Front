import { Component } from '@angular/core';

@Component({
  selector: 'app-mant-deuda-list',
  templateUrl: './mant-deuda-list.component.html',
  styleUrls: ['./mant-deuda-list.component.scss']
})
export class MantDeudaListComponent {

}

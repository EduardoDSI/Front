import { Component } from '@angular/core';

@Component({
  selector: 'app-mant-deuda-register',
  templateUrl: './mant-deuda-register.component.html',
  styleUrls: ['./mant-deuda-register.component.scss']
})
export class MantDeudaRegisterComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-mant-pedido-register',
  templateUrl: './mant-pedido-register.component.html',
  styleUrls: ['./mant-pedido-register.component.scss']
})
export class MantPedidoRegisterComponent {

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WifiHomeRoutingModule } from './wifi-home-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    WifiHomeRoutingModule

  ]
})
export class WifiHomeModule { }
